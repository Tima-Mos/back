package com.example.project_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lr2Application {

    public static void main(String[] args) {
        SpringApplication.run(Lr2Application.class, args);
    }

}
