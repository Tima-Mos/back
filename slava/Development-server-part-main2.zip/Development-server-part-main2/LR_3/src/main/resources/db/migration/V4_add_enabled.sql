ALTER TABLE users
    ADD enabled boolean default true;